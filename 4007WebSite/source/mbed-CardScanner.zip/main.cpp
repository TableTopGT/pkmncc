#include "mbed.h"
#include "ID12RFID.h"

DigitalOut myled(LED1);
Serial rn42(p9, p10); // tx, rx
Serial pc(USBTX, USBRX); // tx, rx
ID12RFID rfid(p14); // uart rx

int main() {
    rn42.baud(115200);
    myled = 0;
    while(1) {
        if (rfid.readable()) {
            myled = !myled; // toggle the LED on a card swipe     
            rn42.printf("%d", rfid.read());             
        }
    }
}
